﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _630furkandenklem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            int n = Convert.ToInt32(textBox1.Text);
            int m = Convert.ToInt32(textBox2.Text);

            for (int x = 1; x <= n; x++)
            {
                for (int y = 1; y <= m; y++)
                {
                    int sonuc = (3 * x) + (y * y) + 3;
                    listBox1.Items.Add("x=" + x + ", y=" + y + " için; 3 * " + x + " + " + y + " ^ 2 + 3 = " + sonuc);
                }
            }

        }
    }
}
